# Fractions Practice (Grade 6) – GitHub Pages

## Quick start
1. Upload `index.html` to a GitHub repo (root folder).
2. In GitHub: **Settings → Pages → Deploy from a branch** → choose `main` and `/ (root)`.
3. Open the GitHub Pages link and practice.

## Features
- Mixed practice: add/sub (same denominator + common denominator), multiplication, division, and word problems (multiple choice)
- Scoring + accuracy + streak
- Review mistakes mode (stored in localStorage)
- Optional timer (10/20/30/45 minutes)
- Accepts answers as: `a/b`, `a b/c` (mixed), or integer
